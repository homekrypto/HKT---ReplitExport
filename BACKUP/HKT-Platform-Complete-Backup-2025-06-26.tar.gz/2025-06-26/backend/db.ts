// Export the robust database wrapper
export { db, pool, executeQuery, isDbOnline } from './db-wrapper';