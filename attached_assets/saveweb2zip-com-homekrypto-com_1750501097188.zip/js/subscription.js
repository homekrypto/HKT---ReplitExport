jQuery(document).ready(function($) {
    $('#subscribeForm').on('submit', function(e) {
        e.preventDefault();
        
        const email = $('#subscribe-email').val();
        const consent = $('#consent-check').is(':checked');
        const submitButton = $(this).find('button[type="submit"]');
        const formMessage = $('#formMessage');
        
        if (!email || !consent) {
            showMessage('Please fill in all required fields.', 'error');
            return;
        }
        
        // Disable button and show loading state
        submitButton.prop('disabled', true).text('Submitting...');
        
        $.ajax({
            url: subscriptionAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'subscribe_to_newsletter',
                email: email,
                nonce: subscriptionAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    showMessage('Thank you for subscribing! Please check your email.', 'success');
                    $('#subscribeForm')[0].reset();
                } else {
                    showMessage(response.data || 'Subscription failed. Please try again.', 'error');
                }
            },
            error: function() {
                showMessage('An error occurred. Please try again later.', 'error');
            },
            complete: function() {
                submitButton.prop('disabled', false).text('SUBMIT');
            }
        });
    });
    
    function showMessage(message, type) {
        const messageDiv = $('#formMessage');
        messageDiv.text(message)
            .removeClass('success error')
            .addClass(type)
            .show();
        
        setTimeout(() => {
            messageDiv.fadeOut();
        }, 5000);
    }
});